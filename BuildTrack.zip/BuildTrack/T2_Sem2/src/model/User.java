package model;

public class User {

    // Data Members
    private int userId;
    private String username;
    private String password;
    private String role;

    // Default Constructor
    public User() {

    }

    // Parameterized Constructor
    public User(int userId, String username, String password, String role) {
        this.userId = userId;
        this.username = username;
        this.password = password;
        this.role = role;
    }

    // Getter Methods
    public int getUserId() {
        return userId;
    }

    public String getUsername() {
        return username;
    }

    public String getPassword() {
        return password;
    }

    public String getRole() {
        return role;
    }

    // Setter Methods
    public void setUserId(int userId) {
        this.userId = userId;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public void setRole(String role) {
        this.role = role;
    }

    // Display Method
    public void displayUser() {
        System.out.println("model.User ID   : " + userId);
        System.out.println("Username  : " + username);
        System.out.println("Role      : " + role);
    }

    // toString Method
    @Override
    public String toString() {
        return "model.User{" +
                "userId=" + userId +
                ", username='" + username + '\'' +
                ", role='" + role + '\'' +
                '}';
    }
}
