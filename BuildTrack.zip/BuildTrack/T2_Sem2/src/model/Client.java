package model;

public class Client extends Person {

    // Data Members
    private int clientId;
    private String companyName;
    private String address;

    // Default Constructor
    public Client() {

    }

    // Parameterized Constructor
    public Client(int clientId, String clientName, String companyName,
                  String phone, String email, String address) {

        this.clientId = clientId;
        this.name = clientName;
        this.companyName = companyName;
        this.phone = phone;
        this.email = email;
        this.address = address;
    }

    // Getter Methods
    public int getClientId() {
        return clientId;
    }

    public String getClientName() {
        return name;
    }

    public String getCompanyName() {
        return companyName;
    }

    public String getPhone() {
        return phone;
    }

    public String getEmail() {
        return email;
    }

    public String getAddress() {
        return address;
    }

    // Setter Methods
    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public void setClientName(String clientName) {
        this.name = clientName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    // Display Method
    public void displayClient() {
        System.out.println("model.Client ID      : " + clientId);
        System.out.println("model.Client Name    : " + name);
        System.out.println("Company Name   : " + companyName);
        System.out.println("Phone          : " + phone);
        System.out.println("Email          : " + email);
        System.out.println("Address        : " + address);
    }

    // toString Method
    @Override
    public String toString() {
        return "model.Client{" +
                "clientId=" + clientId +
                ", clientName='" + name + '\'' +
                ", companyName='" + companyName + '\'' +
                ", phone='" + phone + '\'' +
                ", email='" + email + '\'' +
                ", address='" + address + '\'' +
                '}';
    }
    @Override
    public void displayDetails() {

        System.out.println("Client Name : " + name);
        System.out.println("Phone       : " + phone);
        System.out.println("Email       : " + email);
    }



}
