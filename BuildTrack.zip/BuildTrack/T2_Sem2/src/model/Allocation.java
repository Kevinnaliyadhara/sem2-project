package model;

public class Allocation {

    private int allocationId;
    private int scaffoldId;
    private int componentId;
    private int quantity;
    private int projectId;
    private int siteId;


    private String allocationDate;
    private String returnDate;
    private String actualReturnDate;

    private double rentPerDay;
    private double rentAmount;
    private int lateDays;
    private double penalty;

    private String conditionStatus;
    private String status;

    public Allocation() {
    }

    public int getAllocationId() {
        return allocationId;
    }

    public void setAllocationId(int allocationId) {
        this.allocationId = allocationId;
    }

    public int getScaffoldId() {
        return scaffoldId;
    }

    public void setScaffoldId(int scaffoldId) {
        this.scaffoldId = scaffoldId;
    }
    public int getComponentId() {
        return componentId;
    }

    public void setComponentId(int componentId) {
        this.componentId = componentId;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public int getProjectId() {
        return projectId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public int getSiteId() {
        return siteId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }



    public String getAllocationDate() {
        return allocationDate;
    }

    public void setAllocationDate(String allocationDate) {
        this.allocationDate = allocationDate;
    }

    public String getReturnDate() {
        return returnDate;
    }

    public void setReturnDate(String returnDate) {
        this.returnDate = returnDate;
    }

    public String getActualReturnDate() {
        return actualReturnDate;
    }

    public void setActualReturnDate(String actualReturnDate) {
        this.actualReturnDate = actualReturnDate;
    }

    public double getRentPerDay() {
        return rentPerDay;
    }

    public void setRentPerDay(double rentPerDay) {
        this.rentPerDay = rentPerDay;
    }

    public double getRentAmount() {
        return rentAmount;
    }

    public void setRentAmount(double rentAmount) {
        this.rentAmount = rentAmount;
    }

    public int getLateDays() {
        return lateDays;
    }

    public void setLateDays(int lateDays) {
        this.lateDays = lateDays;
    }

    public double getPenalty() {
        return penalty;
    }

    public void setPenalty(double penalty) {
        this.penalty = penalty;
    }

    public String getConditionStatus() {
        return conditionStatus;
    }

    public void setConditionStatus(String conditionStatus) {
        this.conditionStatus = conditionStatus;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public void displayAllocation() {

        System.out.println("\n========== ALLOCATION DETAILS ==========");
        System.out.println("Allocation ID      : " + allocationId);
        System.out.println("Scaffold ID        : " + scaffoldId);
        System.out.println("Project ID         : " + projectId);
        System.out.println("Site ID            : " + siteId);
        System.out.println("Allocation Date    : " + allocationDate);
        System.out.println("Expected Return    : " + returnDate);
        System.out.println("Actual Return      : " + actualReturnDate);
        System.out.println("Rent Per Day       : ₹" + rentPerDay);
        System.out.println("Total Rent         : ₹" + rentAmount);
        System.out.println("Late Days          : " + lateDays);
        System.out.println("Penalty            : ₹" + penalty);
        System.out.println("Condition          : " + conditionStatus);
        System.out.println("Status             : " + status);
        System.out.println("Component ID       : " + componentId);
        System.out.println("Quantity           : " + quantity);
    }
}