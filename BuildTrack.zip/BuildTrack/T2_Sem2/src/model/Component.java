package model;

public class Component {

    private int componentId;
    private int scaffoldId;
    private String componentName;
    private int quantity;
    private String componentCondition;

    public Component() {
    }

    public int getComponentId() {
        return componentId;
    }

    public void setComponentId(int componentId) {
        this.componentId = componentId;
    }

    public int getScaffoldId() {
        return scaffoldId;
    }

    public void setScaffoldId(int scaffoldId) {
        this.scaffoldId = scaffoldId;
    }

    public String getComponentName() {
        return componentName;
    }

    public void setComponentName(String componentName) {
        this.componentName = componentName;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getComponentCondition() {
        return componentCondition;
    }

    public void setComponentCondition(String componentCondition) {
        this.componentCondition = componentCondition;
    }

    public void displayComponent() {

        System.out.println("\n========== COMPONENT ==========");
        System.out.println("Component ID : " + componentId);
        System.out.println("Scaffold ID : " + scaffoldId);
        System.out.println("Component Name : " + componentName);
        System.out.println("Quantity : " + quantity);
        System.out.println("Condition : " + componentCondition);
    }}