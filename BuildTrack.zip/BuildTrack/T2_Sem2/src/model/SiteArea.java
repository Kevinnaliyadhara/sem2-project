package model;

public class SiteArea {

    // Data Members
    private int areaId;
    private int siteId;
    private String areaName;

    // Default Constructor
    public SiteArea() {

    }

    // Parameterized Constructor
    public SiteArea(int areaId, int siteId, String areaName) {
        this.areaId = areaId;
        this.siteId = siteId;
        this.areaName = areaName;
    }

    // Getter Methods
    public int getAreaId() {
        return areaId;
    }

    public int getSiteId() {
        return siteId;
    }

    public String getAreaName() {
        return areaName;
    }

    // Setter Methods
    public void setAreaId(int areaId) {
        this.areaId = areaId;
    }

    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public void setAreaName(String areaName) {
        this.areaName = areaName;
    }

    // Display Method
    public void displaySiteArea() {
        System.out.println("Area ID   : " + areaId);
        System.out.println("model.Site ID   : " + siteId);
        System.out.println("Area Name : " + areaName);
    }

    // toString Method
    @Override
    public String toString() {
        return "model.SiteArea{" +
                "areaId=" + areaId +
                ", siteId=" + siteId +
                ", areaName='" + areaName + '\'' +
                '}';
    }
}