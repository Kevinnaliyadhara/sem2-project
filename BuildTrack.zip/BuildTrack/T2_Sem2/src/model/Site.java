package model;

public class Site {

    // Data Members
    private int siteId;
    private int projectId;
    private String siteName;
    private String location;
    private double latitude;
    private double longitude;

    // Default Constructor
    public Site() {

    }

    // Parameterized Constructor
    public Site(int siteId, int projectId, String siteName,
                String location, double latitude, double longitude) {

        this.siteId = siteId;
        this.projectId = projectId;
        this.siteName = siteName;
        this.location = location;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    // Getter Methods
    public int getSiteId() {
        return siteId;
    }

    public int getProjectId() {
        return projectId;
    }

    public String getSiteName() {
        return siteName;
    }

    public String getLocation() {
        return location;
    }

    public double getLatitude() {
        return latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    // Setter Methods
    public void setSiteId(int siteId) {
        this.siteId = siteId;
    }

    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public void setSiteName(String siteName) {
        this.siteName = siteName;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    // Display Method
    public void displaySite() {
        System.out.println("model.Site ID      : " + siteId);
        System.out.println("model.Project ID   : " + projectId);
        System.out.println("model.Site Name    : " + siteName);
        System.out.println("Location     : " + location);
        System.out.println("Latitude     : " + latitude);
        System.out.println("Longitude    : " + longitude);
    }

    // toString Method
    @Override
    public String toString() {
        return "model.Site{" +
                "siteId=" + siteId +
                ", projectId=" + projectId +
                ", siteName='" + siteName + '\'' +
                ", location='" + location + '\'' +
                ", latitude=" + latitude +
                ", longitude=" + longitude +
                '}';
    }
}