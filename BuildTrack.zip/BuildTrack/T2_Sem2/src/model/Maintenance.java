package model;

public class Maintenance {

    private int maintenanceId;
    private int scaffoldId;
    private String maintenanceDate;
    private String maintenanceType;
    private double maintenanceCost;
    private String status;
    private String completedDate;

    public Maintenance() {
    }

    public int getMaintenanceId() {
        return maintenanceId;
    }

    public void setMaintenanceId(int maintenanceId) {
        this.maintenanceId = maintenanceId;
    }

    public int getScaffoldId() {
        return scaffoldId;
    }

    public void setScaffoldId(int scaffoldId) {
        this.scaffoldId = scaffoldId;
    }

    public String getMaintenanceDate() {
        return maintenanceDate;
    }

    public void setMaintenanceDate(String maintenanceDate) {
        this.maintenanceDate = maintenanceDate;
    }

    public String getMaintenanceType() {
        return maintenanceType;
    }

    public void setMaintenanceType(String maintenanceType) {
        this.maintenanceType = maintenanceType;
    }

    public double getMaintenanceCost() {
        return maintenanceCost;
    }

    public void setMaintenanceCost(double maintenanceCost) {
        this.maintenanceCost = maintenanceCost;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
    public String getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(String completedDate) {
        this.completedDate = completedDate;
    }


    public void displayMaintenance() {

        System.out.println("\n========== MAINTENANCE ==========");
        System.out.println("Maintenance ID   : " + maintenanceId);
        System.out.println("Scaffold ID      : " + scaffoldId);
        System.out.println("Maintenance Date : " + maintenanceDate);
        System.out.println("Maintenance Type : " + maintenanceType);
        System.out.println("Cost             : " + maintenanceCost);
        System.out.println("Completed Date   : " + completedDate);
        System.out.println("Status           : " + status);
    }
}