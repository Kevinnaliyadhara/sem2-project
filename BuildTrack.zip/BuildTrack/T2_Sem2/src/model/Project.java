package model;

public class Project {

    // Data Members
    private int projectId;
    private int clientId;
    private String projectName;
    private String startDate;
    private String endDate;
    private String status;
    private double estimatedCost;

    // Default Constructor
    public Project() {

    }

    // Parameterized Constructor
    public Project(int projectId, int clientId, String projectName,
                   String startDate, String endDate,
                   String status, double estimatedCost) {

        this.projectId = projectId;
        this.clientId = clientId;
        this.projectName = projectName;
        this.startDate = startDate;
        this.endDate = endDate;
        this.status = status;
        this.estimatedCost = estimatedCost;
    }

    // Getter Methods
    public int getProjectId() {
        return projectId;
    }

    public int getClientId() {
        return clientId;
    }

    public String getProjectName() {
        return projectName;
    }

    public String getStartDate() {
        return startDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public String getStatus() {
        return status;
    }

    // Setter Methods
    public void setProjectId(int projectId) {
        this.projectId = projectId;
    }

    public void setClientId(int clientId) {
        this.clientId = clientId;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    // Display Method
    public void displayProject() {
        System.out.println("Project ID   : " + projectId);
        System.out.println("Client ID    : " + clientId);
        System.out.println("Project Name : " + projectName);
        System.out.println("Start Date   : " + startDate);
        System.out.println("End Date     : " + endDate);
        System.out.println("Status       : " + status);
        System.out.println("Estimated Cost : " + estimatedCost);
    }
    public double getEstimatedCost() {
        return estimatedCost;
    }
    public void setEstimatedCost(double estimatedCost) {
        this.estimatedCost = estimatedCost;
    }

    // toString Method

    @Override
    public String toString() {
        return "Project{" +
                "projectId=" + projectId +
                ", clientId=" + clientId +
                ", projectName='" + projectName + '\'' +
                ", startDate='" + startDate + '\'' +
                ", endDate='" + endDate + '\'' +
                ", status='" + status + '\'' +
                ", estimatedCost=" + estimatedCost +
                '}';
    }
}