package model;

public class Scaffold {

    private int scaffoldId;
    private String scaffoldCode;
    private String scaffoldType;
    private String status;
    private String currentSite;
    private String currentArea;

    public Scaffold() {
    }

    public int getScaffoldId() {
        return scaffoldId;
    }

    public void setScaffoldId(int scaffoldId) {
        this.scaffoldId = scaffoldId;
    }

    public String getScaffoldCode() {
        return scaffoldCode;
    }

    public void setScaffoldCode(String scaffoldCode) {
        this.scaffoldCode = scaffoldCode;
    }

    public String getScaffoldType() {
        return scaffoldType;
    }

    public void setScaffoldType(String scaffoldType) {
        this.scaffoldType = scaffoldType;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getCurrentSite() {
        return currentSite;
    }

    public void setCurrentSite(String currentSite) {
        this.currentSite = currentSite;
    }

    public String getCurrentArea() {
        return currentArea;
    }

    public void setCurrentArea(String currentArea) {
        this.currentArea = currentArea;
    }

    public void displayScaffold() {

        System.out.println("\n========== SCAFFOLD ==========");
        System.out.println("Scaffold ID   : " + scaffoldId);
        System.out.println("Code          : " + scaffoldCode);
        System.out.println("Type          : " + scaffoldType);
        System.out.println("Status        : " + status);
        System.out.println("Current Site  : " + currentSite);
        System.out.println("Current Area  : " + currentArea);
    }
}