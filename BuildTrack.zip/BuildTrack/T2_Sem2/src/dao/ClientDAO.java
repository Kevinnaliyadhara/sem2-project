package dao;
import database.DatabaseConnection;
import model.Client;
import java.sql.*;
import java.util.HashMap;
import java.sql.Statement;
import java.sql.ResultSet;
import utils.ActivityLogger;
import java.util.ArrayList;

public class ClientDAO {
    ArrayList<Client> clientList = new ArrayList<>();

    Connection con;

    public ClientDAO() {
        con = DatabaseConnection.getConnection();
    }


    // Add Client
    public boolean addClient(Client client) {

        String sql = "INSERT INTO clients(client_name, company_name, phone, email, address) VALUES (?, ?, ?, ?, ?)";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, client.getClientName());
            ps.setString(2, client.getCompanyName());
            ps.setString(3, client.getPhone());
            ps.setString(4, client.getEmail());
            ps.setString(5, client.getAddress());
            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                ActivityLogger.log("Client Added Successfully");
                return true;
            }
            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }


    // Display All Clients
    public void displayClients() {

        String sql = "SELECT * FROM clients";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(rs.getInt("client_id") + " "
                        + rs.getString("client_name") + " "
                        + rs.getString("company_name"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Search Client by Name (LIKE)
    public void searchClientByName(String name) {

        String sql = "SELECT * FROM clients WHERE client_name LIKE ? ORDER BY client_name";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, "%" + name + "%");

            ResultSet rs = ps.executeQuery();

            System.out.println("\n========== SEARCH RESULT ==========");

            while (rs.next()) {

                System.out.println("Client ID      : " + rs.getInt("client_id"));
                System.out.println("Client Name    : " + rs.getString("client_name"));
                System.out.println("Company Name   : " + rs.getString("company_name"));
                System.out.println("Phone          : " + rs.getString("phone"));
                System.out.println("Email          : " + rs.getString("email"));
                System.out.println("Address        : " + rs.getString("address"));
                System.out.println("--------------------------------------");
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    // Load Clients into HashMap
    public HashMap<Integer, Client> getClientMap() {

        HashMap<Integer, Client> clientMap = new HashMap<>();

        String sql = "SELECT * FROM clients";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                Client client = new Client();

                client.setClientId(rs.getInt("client_id"));
                client.setClientName(rs.getString("client_name"));
                client.setCompanyName(rs.getString("company_name"));
                client.setPhone(rs.getString("phone"));
                client.setEmail(rs.getString("email"));
                client.setAddress(rs.getString("address"));

                clientList.add(client);
                clientMap.put(client.getClientId(), client);
            }
            for (Client c : clientList) {

                System.out.println(c);

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return clientMap;
    }

}