package dao;

public interface ReportOperations  {

    void showClientProjectReport();


    void showFullProjectReport();


    void showProjectCostReport();


}