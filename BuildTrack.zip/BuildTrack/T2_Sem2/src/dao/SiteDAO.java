    package dao;

    import database.DatabaseConnection;
    import model.Site;

    import java.sql.*;

    public class SiteDAO {

        Connection con;

        public SiteDAO() {
            con = DatabaseConnection.getConnection();
        }

        // Add Site
        public boolean addSite(Site site) {

            String sql = "INSERT INTO sites(project_id, site_name, location, latitude, longitude) VALUES (?, ?, ?, ?, ?)";

            try {

                PreparedStatement ps = con.prepareStatement(sql);

                ps.setInt(1, site.getProjectId());
                ps.setString(2, site.getSiteName());
                ps.setString(3, site.getLocation());
                ps.setDouble(4, site.getLatitude());
                ps.setDouble(5, site.getLongitude());

                int rows = ps.executeUpdate();

                if (rows > 0) {
                    con.commit();
                    return true;
                }

                return false;

            } catch (SQLException e) {

                try {
                    con.rollback();
                    System.out.println("Transaction Rolled Back.");
                } catch (SQLException ex) {
                    ex.printStackTrace();
                }

                e.printStackTrace();
                return false;
            }
        }


        // Display All Sites
        public void displaySites() {

            String sql = "SELECT * FROM sites";

            try {

                Statement st = con.createStatement();

                ResultSet rs = st.executeQuery(sql);

                while (rs.next()) {

                    System.out.println(rs.getInt("site_id") + " "
                            + rs.getString("site_name") + " "
                            + rs.getString("location"));
                }

            } catch (SQLException e) {

                e.printStackTrace();
            }
        }
    }