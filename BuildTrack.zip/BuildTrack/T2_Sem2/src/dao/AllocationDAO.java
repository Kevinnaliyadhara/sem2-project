package dao;

import database.DatabaseConnection;
import model.Allocation;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import datastructure.MaintenanceQueue;
import datastructure.OperationStack;

import java.sql.*;

public class AllocationDAO {

    Connection con;
    int componentId = 0;
    int quantity = 0;

    public AllocationDAO() {
        con = DatabaseConnection.getConnection();
    }

    // ================= ADD ALLOCATION =================

    public boolean addAllocation(Allocation allocation) {

        String sql ="INSERT INTO allocations (scaffold_id, component_id, quantity, project_id, site_id, allocation_date, return_date, rent_per_day, rent_amount, late_days, penalty, condition_status, status) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)";
        try {

            PreparedStatement ps = con.prepareStatement(sql);


            ps.setInt(1, allocation.getScaffoldId());
            ps.setInt(2, allocation.getComponentId());
            ps.setInt(3, allocation.getQuantity());
            ps.setInt(4, allocation.getProjectId());
            ps.setInt(5, allocation.getSiteId());

            ps.setDate(6, Date.valueOf(allocation.getAllocationDate()));
            ps.setDate(7, Date.valueOf(allocation.getReturnDate()));

            ps.setDouble(8, allocation.getRentPerDay());
            ps.setDouble(9, 0);

            ps.setInt(10, 0);
            ps.setDouble(11, 0);

            ps.setString(12, "Good");
            ps.setString(13, "Allocated");
            ComponentDAO componentDAO = new ComponentDAO();

            int available = componentDAO.getAvailableStock(allocation.getComponentId());

            if (available < allocation.getQuantity()) {

                System.out.println("==================================");
                System.out.println(" Component Out Of Stock");
                System.out.println(" Available : " + available);
                System.out.println(" Requested : " + allocation.getQuantity());
                System.out.println("==================================");

                return false;
            }

            int stock = componentDAO.getAvailableStock(allocation.getComponentId());

            if (allocation.getQuantity() > stock) {

                System.out.println("\nOut Of Stock.");
                System.out.println("Available : " + stock);
                System.out.println("Requested : " + allocation.getQuantity());

                return false;
            }

            int rows = ps.executeUpdate();


            if (rows > 0) {

                PreparedStatement updateScaffold = con.prepareStatement(
                        "UPDATE scaffolds SET status=? WHERE scaffold_id=?");

                updateScaffold.setString(1, "Allocated");
                updateScaffold.setInt(2, allocation.getScaffoldId());

                updateScaffold.executeUpdate();
                OperationStack stack = new OperationStack();
                stack.pushOperation("Allocated Scaffold ID : " + allocation.getScaffoldId());

                con.commit();

                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

            return false;
        }
    }

    // ================= DISPLAY =================

    public void displayAllocations() {

        String sql = "SELECT * FROM allocations";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n================ ALLOCATION LIST ================");

            while (rs.next()) {

                System.out.println("------------------------------------------");

                System.out.println("Allocation ID      : " + rs.getInt("allocation_id"));
                System.out.println("Scaffold ID        : " + rs.getInt("scaffold_id"));
                System.out.println("Project ID         : " + rs.getInt("project_id"));
                System.out.println("Site ID            : " + rs.getInt("site_id"));
                System.out.println("Allocation Date    : " + rs.getDate("allocation_date"));
                System.out.println("Expected Return    : " + rs.getDate("return_date"));
                System.out.println("Actual Return      : " + rs.getDate("actual_return_date"));
                System.out.println("Rent Per Day       : " + rs.getDouble("rent_per_day"));
                System.out.println("Rent Amount        : " + rs.getDouble("rent_amount"));
                System.out.println("Late Days          : " + rs.getInt("late_days"));
                System.out.println("Penalty            : " + rs.getDouble("penalty"));
                System.out.println("Condition          : " + rs.getString("condition_status"));
                System.out.println("Status             : " + rs.getString("status"));
                System.out.println("Component ID       : " + rs.getInt("component_id"));
                System.out.println("Quantity           : " + rs.getInt("quantity"));
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    // ================= UPDATE ALLOCATION =================

    public boolean updateAllocation(Allocation allocation) {

        String sql =
                "UPDATE allocations SET scaffold_id=?, project_id=?, site_id=?, rent_per_day=?, allocation_date=?, return_date=? WHERE allocation_id=?";
        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, allocation.getScaffoldId());
            ps.setInt(2, allocation.getProjectId());
            ps.setInt(3, allocation.getSiteId());
            ps.setDouble(4, allocation.getRentPerDay());

            ps.setDate(5, Date.valueOf(allocation.getAllocationDate()));
            ps.setDate(6, Date.valueOf(allocation.getReturnDate()));

            ps.setInt(7, allocation.getAllocationId());

            int rows = ps.executeUpdate();
            PreparedStatement stockUpdate = con.prepareStatement(
                    "UPDATE components SET available_quantity = available_quantity - ?, allocated_quantity = allocated_quantity + ? WHERE component_id=?");

            stockUpdate.setInt(1, allocation.getQuantity());
            stockUpdate.setInt(2, allocation.getQuantity());
            stockUpdate.setInt(3, allocation.getComponentId());

            stockUpdate.executeUpdate();


            if (rows > 0) {

                con.commit();

                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

            return false;
        }
    }
    // ================= DELETE ALLOCATION =================

    public boolean deleteAllocation(int allocationId) {

        String sql = "DELETE FROM allocations WHERE allocation_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, allocationId);

            int rows = ps.executeUpdate();

            if (rows > 0) {


                con.commit();

                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

            return false;
        }
    }
    public boolean returnScaffold(int allocationId,
                                  String actualReturnDate,
                                  String condition,
                                  double maintenanceCost){

        try {
            // Get Allocation Details
            String checkSql =
                    "SELECT status FROM allocations WHERE allocation_id=?";

            PreparedStatement cps = con.prepareStatement(checkSql);

            cps.setInt(1, allocationId);

            ResultSet crs = cps.executeQuery();

            if (!crs.next()) {

                System.out.println("\nAllocation ID Not Found.");

                return false;
            }

            if (crs.getString("status").equalsIgnoreCase("Returned")) {

                System.out.println("\nAlready Returned.");

                return false;
            }

            PreparedStatement ps1 = con.prepareStatement("SELECT allocation_date, return_date, rent_per_day, scaffold_id, component_id, quantity FROM allocations WHERE allocation_id=?");

            ps1.setInt(1, allocationId);

            ResultSet rs = ps1.executeQuery();

            double rentPerDay = 0;

            double totalRent = 0;

            int lateDays = 0;

            double penalty = 0;

            int scaffoldId = 0;

            if (rs.next()) {

                LocalDate allocationDate = rs.getDate("allocation_date").toLocalDate();

                LocalDate expectedReturn = rs.getDate("return_date").toLocalDate();

                LocalDate actualReturn = LocalDate.parse(actualReturnDate);

                rentPerDay = rs.getDouble("rent_per_day");

                scaffoldId = rs.getInt("scaffold_id");

                componentId = rs.getInt("component_id");
                quantity = rs.getInt("quantity");

                long totalDays = ChronoUnit.DAYS.between(allocationDate, actualReturn);

                if (totalDays <= 0) {

                    totalDays = 1;

                }

                totalRent = totalDays * rentPerDay;

                if (actualReturn.isAfter(expectedReturn)) {

                    lateDays = (int) ChronoUnit.DAYS.between(expectedReturn, actualReturn);

                    penalty = lateDays * 100;

                }

            }

            // Allocation Update
            String sql = "UPDATE allocations SET actual_return_date=?, rent_amount=?, late_days=?, penalty=?, condition_status=?, status=? WHERE allocation_id=?";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDate(1, java.sql.Date.valueOf(actualReturnDate));

            ps.setDouble(2, totalRent);

            ps.setInt(3, lateDays);

            ps.setDouble(4, penalty);

            ps.setString(5, condition);

            ps.setString(6, "Returned");

            ps.setInt(7, allocationId);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                PreparedStatement stockPS;

                if (condition.equalsIgnoreCase("Good")) {

                    stockPS = con.prepareStatement(
                            "UPDATE components SET available_quantity = available_quantity + ?, allocated_quantity = allocated_quantity - ? WHERE component_id=?");

                    stockPS.setInt(1, quantity);
                    stockPS.setInt(2, quantity);
                    stockPS.setInt(3, componentId);

                } else {

                    stockPS = con.prepareStatement(
                            "UPDATE components SET damaged_quantity = damaged_quantity + ?, allocated_quantity = allocated_quantity - ? WHERE component_id=?");

                    stockPS.setInt(1, quantity);
                    stockPS.setInt(2, quantity);
                    stockPS.setInt(3, componentId);

                }

                stockPS.executeUpdate();
                // Update Scaffold Status

                PreparedStatement scaffoldPS;

                if (condition.equalsIgnoreCase("Good")) {

                    scaffoldPS = con.prepareStatement(
                            "UPDATE scaffolds SET status=? WHERE scaffold_id=?");

                    scaffoldPS.setString(1, "Available");
                    scaffoldPS.setInt(2, scaffoldId);

                    scaffoldPS.executeUpdate();

                } else {

                    scaffoldPS = con.prepareStatement(
                            "UPDATE scaffolds SET status=? WHERE scaffold_id=?");

                    scaffoldPS.setString(1, "Maintenance");
                    scaffoldPS.setInt(2, scaffoldId);

                    scaffoldPS.executeUpdate();

                    PreparedStatement maintenancePS = con.prepareStatement(
                            "INSERT INTO maintenance (scaffold_id, component_id, quantity, maintenance_date, maintenance_type, maintenance_cost, completed_date, status)VALUES (?,?,?,?,?,?,?,?)");
                    maintenancePS.setInt(1, scaffoldId);
                    maintenancePS.setInt(2, componentId);
                    maintenancePS.setInt(3, quantity);
                    maintenancePS.setDate(4, Date.valueOf(actualReturnDate));
                    maintenancePS.setString(5, "Repair");
                    maintenancePS.setDouble(6, maintenanceCost);
                    maintenancePS.setNull(7, Types.DATE);
                    maintenancePS.setString(8, "Pending");
                    maintenancePS.executeUpdate();

                    MaintenanceQueue queue = new MaintenanceQueue();
                    queue.addRequest("Scaffold ID : " + scaffoldId + " -> Pending Maintenance");

                }

                double totalAmount = totalRent + penalty + maintenanceCost;

                System.out.println("\n======================================");
                System.out.println("            FINAL BILL");
                System.out.println("======================================");
                System.out.println("Scaffold ID       : " + scaffoldId);

            System.out.println("Rent Amount       : ₹" + totalRent);
                System.out.println("Condition         : " + condition);
                System.out.println("Late Days         : " + lateDays);
                System.out.println("Penalty           : ₹" + penalty);
                System.out.println("Maintenance Cost  : ₹" + maintenanceCost);
                System.out.println("--------------------------------------");
                System.out.println("Total Amount      : ₹" + totalAmount);
                System.out.println("======================================");

                con.commit();

                return true;


            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();

            return false;
        }
    }

}