package dao;

import database.DatabaseConnection;
import model.SiteArea;

import java.sql.*;

public class SiteAreaDAO {

    Connection con;

    public SiteAreaDAO() {
        con = DatabaseConnection.getConnection();
    }

    // Add Site Area
    public boolean addSiteArea(SiteArea area) {

        String sql = "INSERT INTO site_areas(site_id, area_name) VALUES (?, ?)";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, area.getSiteId());
            ps.setString(2, area.getAreaName());

            int rows = ps.executeUpdate();

            con.commit();

            return rows > 0;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }



    // Display All model.Site Areas
    public void displaySiteAreas() {

        String sql = "SELECT * FROM site_areas";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(rs.getInt("area_id") + " "
                        + rs.getString("area_name"));
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
}