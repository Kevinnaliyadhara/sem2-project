package dao;

import database.DatabaseConnection;
import model.Project;
import java.sql.Savepoint;
import java.sql.*;
import utils.ActivityLogger;
public class ProjectDAO {

    Connection con;

    public ProjectDAO() {
        con = DatabaseConnection.getConnection();
    }

    // Add Project
    public boolean addProject(Project project) {

        String sql = "INSERT INTO projects\n" +
                "(client_id, project_name, start_date, end_date, status, estimated_cost)VALUES (?, ?, ?, ?, ?, ?)";

        try {

            PreparedStatement ps = con.prepareStatement(sql);
            ps.setDouble(6, project.getEstimatedCost());
            ps.setInt(1, project.getClientId());
            ps.setString(2, project.getProjectName());
            ps.setString(3, project.getStartDate());
            ps.setString(4, project.getEndDate());
            ps.setString(5, project.getStatus());
            Savepoint sp = con.setSavepoint("BeforeProjectInsert");

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                ActivityLogger.log("Project Added Successfully");
                return true;
            }
            return false;



        } catch (SQLException e) {
            Savepoint sp=null;
            try {
                sp = con.setSavepoint("BeforeProjectInsert");
                con.rollback(sp);

                System.out.println("Rolled Back To Savepoint.");

            } catch (SQLException ex) {

                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }

    }

    // Update Project
    public boolean updateProject(Project project) {

        String sql = "UPDATE projects SET client_id=?, project_name=?, start_date=?, end_date=?, status=?, estimated_cost=? WHERE project_id=?;";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, project.getClientId());
            ps.setString(2, project.getProjectName());
            ps.setString(3, project.getStartDate());
            ps.setString(4, project.getEndDate());
            ps.setString(5, project.getStatus());
            ps.setDouble(6, project.getEstimatedCost());
            ps.setInt(7, project.getProjectId());
            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                ActivityLogger.log("Project Updated Successfully");
                return true;
            }
            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // Delete Project
    public boolean deleteProject(int id) {

        String sql = "DELETE FROM projects WHERE project_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);
            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                ActivityLogger.log("Client Deleted Successfully");
                return true;
            }
            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }


    // Search Project by Estimated Cost (BETWEEN)
    public void searchProjectByCost(double minCost, double maxCost) {

        String sql = "SELECT * FROM projects WHERE estimated_cost BETWEEN ? AND ? ORDER BY estimated_cost";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDouble(1, minCost);
            ps.setDouble(2, maxCost);

            ResultSet rs = ps.executeQuery();

            System.out.println("\n========== PROJECTS ==========");

            while (rs.next()) {

                System.out.println("--------------------------------");
                System.out.println("Project Name   : " + rs.getString("project_name"));
                System.out.println("Status         : " + rs.getString("status"));
                System.out.println("Estimated Cost : " + rs.getDouble("estimated_cost"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Highest Cost Project (Subquery)
    public void showHighestCostProject() {

        String sql = "SELECT * FROM projects " +
                "WHERE estimated_cost = " +
                "(SELECT MAX(estimated_cost) FROM projects)";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n========== HIGHEST COST PROJECT ==========");

            while (rs.next()) {

                System.out.println("Project Name   : " + rs.getString("project_name"));
                System.out.println("Status         : " + rs.getString("status"));
                System.out.println("Estimated Cost : " + rs.getDouble("estimated_cost"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    // Projects Above Average Cost (Subquery)
    public void showProjectsAboveAverageCost() {

        String sql = "SELECT * FROM projects " +
                "WHERE estimated_cost > " +
                "(SELECT AVG(estimated_cost) FROM projects)";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n===== PROJECTS ABOVE AVERAGE COST =====");

            while (rs.next()) {

                System.out.println("--------------------------------");
                System.out.println("Project Name   : " + rs.getString("project_name"));
                System.out.println("Estimated Cost : " + rs.getDouble("estimated_cost"));
                System.out.println("Status         : " + rs.getString("status"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }


    // Display All Projects
    public void displayProjects() {

        String sql = "SELECT * FROM projects";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(
                        rs.getInt("project_id") + " " +
                                rs.getString("project_name") + " " +
                                rs.getString("status") + " " +
                                rs.getDouble("estimated_cost")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}