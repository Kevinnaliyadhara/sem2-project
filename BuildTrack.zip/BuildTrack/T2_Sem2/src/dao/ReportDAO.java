package dao;
import java.util.ArrayList;
import model.Project;
import database.DatabaseConnection;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class ReportDAO implements ReportOperations {

    Connection con;

    public ReportDAO() {
        con = DatabaseConnection.getConnection();
    }

    // model.Client - model.Project Report (INNER JOIN)
    public void showClientProjectReport() {

        String sql = "SELECT c.client_name, p.project_name, p.status " +
                "FROM clients c " +
                "INNER JOIN projects p ON c.client_id = p.client_id";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n========== CLIENT PROJECT REPORT ==========");

            while (rs.next()) {

                System.out.printf("%-20s %-25s %-15s%n",
                        rs.getString("client_name"),
                        rs.getString("project_name"),
                        rs.getString("status"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Full Project Report
    public void showFullProjectReport() {

        String sql = "SELECT c.client_name, p.project_name, s.site_name, sa.area_name, p.status " +
                "FROM clients c " +
                "INNER JOIN projects p ON c.client_id = p.client_id " +
                "INNER JOIN sites s ON p.project_id = s.project_id " +
                "INNER JOIN site_areas sa ON s.site_id = sa.site_id";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n==================== FULL PROJECT REPORT ====================");

            System.out.printf("%-20s %-20s %-15s %-20s %-15s%n",
                    "Client",
                    "Project",
                    "Site",
                    "Area",
                    "Status");

            System.out.println("--------------------------------------------------------------------------");

            while (rs.next()) {

                System.out.printf("%-20s %-20s %-15s %-20s %-15s%n",
                        rs.getString("client_name"),
                        rs.getString("project_name"),
                        rs.getString("site_name"),
                        rs.getString("area_name"),
                        rs.getString("status"));
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // Project Cost Report (SUM, AVG, MIN, MAX)
    public void showProjectCostReport() {

        String sql = "SELECT " +
                "SUM(estimated_cost) AS total_cost, " +
                "AVG(estimated_cost) AS average_cost, " +
                "MIN(estimated_cost) AS minimum_cost, " +
                "MAX(estimated_cost) AS maximum_cost " +
                "FROM projects";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            if (rs.next()) {

                System.out.println("\n========== PROJECT COST REPORT ==========");

                System.out.println("Total Cost    : " + rs.getDouble("total_cost"));
                System.out.println("Average Cost  : " + rs.getDouble("average_cost"));
                System.out.println("Minimum Cost  : " + rs.getDouble("minimum_cost"));
                System.out.println("Maximum Cost  : " + rs.getDouble("maximum_cost"));
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }

    // Rental Income Report
    public void showRentalIncomeReport() {

        String sql = "SELECT COUNT(*) AS total_rentals, SUM(rent_amount) AS total_income FROM allocations";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n========== RENTAL INCOME REPORT ==========");

            if (rs.next()) {

                System.out.println("----------------------------------------");
                System.out.println("Total Rentals : " + rs.getInt("total_rentals"));
                System.out.println("Total Income  : ₹" + rs.getDouble("total_income"));
                System.out.println("----------------------------------------");
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    // Maintenance Report
    public void showMaintenanceReport() {

        String sql = "SELECT " +
                "COUNT(*) AS total_maintenance, " +
                "SUM(CASE WHEN status='Pending' THEN 1 ELSE 0 END) AS pending, " +
                "SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed, " +
                "SUM(maintenance_cost) AS total_cost " +
                "FROM maintenance";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n========== MAINTENANCE REPORT ==========");

            if (rs.next()) {

                System.out.println("----------------------------------------");
                System.out.println("Total Maintenance : " + rs.getInt("total_maintenance"));
                System.out.println("Pending           : " + rs.getInt("pending"));
                System.out.println("Completed         : " + rs.getInt("completed"));
                System.out.println("Total Cost        : ₹" + rs.getDouble("total_cost"));
                System.out.println("----------------------------------------");
            }

        } catch (SQLException e) {

            e.printStackTrace();
        }
    }
    public void showAvailableScaffoldReport() {

        String sql = "SELECT scaffold_id, scaffold_code, scaffold_type, status FROM scaffolds WHERE status='Available' ORDER BY scaffold_id";

        try {

            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery(sql);

            System.out.println("\n========== AVAILABLE SCAFFOLD REPORT ==========");

            System.out.printf("%-15s %-20s %-20s %-15s%n",
                    "ID", "Code", "Type", "Status");

            System.out.println("----------------------------------------------------------------");

            while (rs.next()) {

                System.out.printf("%-15d %-20s %-20s %-15s%n",
                        rs.getInt("scaffold_id"),
                        rs.getString("scaffold_code"),
                        rs.getString("scaffold_type"),
                        rs.getString("status"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}