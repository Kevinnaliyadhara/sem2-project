package dao;

import database.DatabaseConnection;
import model.Scaffold;

import java.sql.*;

public class ScaffoldDAO {

    Connection con;

    public ScaffoldDAO() {
        con = DatabaseConnection.getConnection();
    }

    // Add Scaffold
    public boolean addScaffold(Scaffold scaffold) {

        String sql = "INSERT INTO scaffolds(scaffold_code, scaffold_type, status, current_site, current_area) VALUES (?, ?, ?, ?, ?)";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, scaffold.getScaffoldCode());
            ps.setString(2, scaffold.getScaffoldType());
            ps.setString(3, scaffold.getStatus());
            ps.setString(4, scaffold.getCurrentSite());
            ps.setString(5, scaffold.getCurrentArea());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // Display All Scaffolds
    public void displayScaffolds() {

        String sql = "SELECT * FROM scaffolds";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println(
                        rs.getInt("scaffold_id") + "  " +
                                rs.getString("scaffold_code") + "  " +
                                rs.getString("scaffold_type") + "  " +
                                rs.getString("status") + "  " +
                                rs.getString("current_site") + "  " +
                                rs.getString("current_area")
                );
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update Scaffold
    public boolean updateScaffold(Scaffold scaffold) {

        String sql = "UPDATE scaffolds SET scaffold_code=?, scaffold_type=?, status=?, current_site=?, current_area=? WHERE scaffold_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, scaffold.getScaffoldCode());
            ps.setString(2, scaffold.getScaffoldType());
            ps.setString(3, scaffold.getStatus());
            ps.setString(4, scaffold.getCurrentSite());
            ps.setString(5, scaffold.getCurrentArea());
            ps.setInt(6, scaffold.getScaffoldId());

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // Delete Scaffold
    public boolean deleteScaffold(int id) {

        String sql = "DELETE FROM scaffolds WHERE scaffold_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }
}