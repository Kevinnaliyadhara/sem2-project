package dao;

import database.DatabaseConnection;
import model.Maintenance;

import java.sql.*;

public class MaintenanceDAO {

    Connection con;

    public MaintenanceDAO() {
        con = DatabaseConnection.getConnection();
    }

    // Display Maintenance
    public void displayMaintenance() {

        String sql = "SELECT * FROM maintenance";

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println("----------------------------------------");
                System.out.println("Maintenance ID   : " + rs.getInt("maintenance_id"));
                System.out.println("Scaffold ID      : " + rs.getInt("scaffold_id"));
                System.out.println("Maintenance Date : " + rs.getString("maintenance_date"));
                System.out.println("Type             : " + rs.getString("maintenance_type"));
                System.out.println("Cost             : ₹" + rs.getDouble("maintenance_cost"));
                System.out.println("Completed Date   : " + rs.getString("completed_date"));
                System.out.println("Status           : " + rs.getString("status"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update Maintenance
    public boolean updateMaintenance(Maintenance maintenance) {

        String sql = "UPDATE maintenance SET maintenance_cost=?, completed_date=?, status=? WHERE maintenance_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setDouble(1, maintenance.getMaintenanceCost());
            ps.setDate(2, Date.valueOf(maintenance.getCompletedDate()));
            ps.setString(3, maintenance.getStatus());
            ps.setInt(4, maintenance.getMaintenanceId());

            int rows = ps.executeUpdate();

            if (rows > 0) {

                if (maintenance.getStatus().equalsIgnoreCase("Completed")) {

                    PreparedStatement ps3 = con.prepareStatement(
                            "SELECT scaffold_id, component_id, quantity FROM maintenance WHERE maintenance_id=?");

                    ps3.setInt(1, maintenance.getMaintenanceId());

                    ResultSet rs = ps3.executeQuery();

                    if (rs.next()) {

                        int scaffoldId = rs.getInt("scaffold_id");
                        int componentId = rs.getInt("component_id");
                        int qty = rs.getInt("quantity");

                        // Update Scaffold Status
                        PreparedStatement ps2 = con.prepareStatement(
                                "UPDATE scaffolds SET status=? WHERE scaffold_id=?");

                        ps2.setString(1, "Available");
                        ps2.setInt(2, scaffoldId);

                        ps2.executeUpdate();

                        // Update Component Stock
                        PreparedStatement ps4 = con.prepareStatement(
                                "UPDATE components SET available_quantity = available_quantity + ?, damaged_quantity = damaged_quantity - ? WHERE component_id=?");

                        ps4.setInt(1, qty);
                        ps4.setInt(2, qty);
                        ps4.setInt(3, componentId);

                        ps4.executeUpdate();
                    }
                }

                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // Delete Maintenance
    public boolean deleteMaintenance(int id) {

        String sql = "DELETE FROM maintenance WHERE maintenance_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }
}