package dao;

import database.DatabaseConnection;
import model.User;
import utils.ActivityLogger;
import java.sql.*;
public class UserDAO {

    Connection con;

    public UserDAO() {
        con = DatabaseConnection.getConnection();
    }


    // Login
    public boolean login(String username, String password) {

        String sql = "SELECT * FROM users WHERE username=? AND password=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, username);
            ps.setString(2, password);

            ResultSet rs = ps.executeQuery();

            return rs.next();

        } catch (SQLException e) {

            e.printStackTrace();
            return false;
        }
    }

}