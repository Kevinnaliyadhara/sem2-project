package dao;

import database.DatabaseConnection;
import model.Component;

import java.sql.*;

public class ComponentDAO {

    Connection con;

    public ComponentDAO() {

        con = DatabaseConnection.getConnection();

        if (con == null) {

            throw new RuntimeException("Database Connection Failed.");
        }
    }

    // Add Component
    public boolean addComponent(Component component) {

        String sql = "INSERT INTO components(scaffold_id, component_name, quantity, component_condition, available_quantity, allocated_quantity, damaged_quantity) VALUES (?, ?, ?, ?, ?, ?, ?)";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, component.getScaffoldId());
            ps.setString(2, component.getComponentName());
            ps.setInt(3, component.getQuantity());
            ps.setString(4, component.getComponentCondition());
            ps.setInt(5, component.getQuantity());
            ps.setInt(6, 0);
            ps.setInt(7, 0);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // Display Components
    public void displayComponents() {

        String sql = "SELECT * FROM components";

        try {

            Statement st = con.createStatement();
            boolean found = false;
            while(found)
            {
                found = true;
            }
            if (!found) {
                System.out.println("\nNo Components Found.");
            }

            ResultSet rs = st.executeQuery(sql);

            while (rs.next()) {

                System.out.println("--------------------------------------------");
                System.out.println("Component ID      : " + rs.getInt("component_id"));
                System.out.println("Scaffold ID       : " + rs.getInt("scaffold_id"));
                System.out.println("Component Name    : " + rs.getString("component_name"));
                System.out.println("Total Quantity    : " + rs.getInt("quantity"));
                System.out.println("Available Stock   : " + rs.getInt("available_quantity"));
                System.out.println("Allocated Stock   : " + rs.getInt("allocated_quantity"));
                System.out.println("Damaged Stock     : " + rs.getInt("damaged_quantity"));
                System.out.println("Condition         : " + rs.getString("component_condition"));
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    // Update Component
    public boolean updateComponent(Component component) {

        String sql = "UPDATE components SET scaffold_id=?, component_name=?, quantity=?, component_condition=?, available_quantity=? WHERE component_id=?";
        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, component.getScaffoldId());
            ps.setString(2, component.getComponentName());
            ps.setInt(3, component.getQuantity());
            ps.setString(4, component.getComponentCondition());
            ps.setInt(5, component.getQuantity());
            ps.setInt(6, component.getComponentId());
            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }

    // Delete Component
    public boolean deleteComponent(int id) {

        String sql = "DELETE FROM components WHERE component_id=?";

        try {

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, id);

            int rows = ps.executeUpdate();

            if (rows > 0) {
                con.commit();
                return true;
            }

            return false;

        } catch (SQLException e) {

            try {
                con.rollback();
                System.out.println("Transaction Rolled Back.");
            } catch (SQLException ex) {
                if (e.getErrorCode() == 1451) {

                    System.out.println("\nComponent is allocated. Delete allocation first.");
                    return false;
                }
                ex.printStackTrace();
            }

            e.printStackTrace();
            return false;
        }
    }
    public int getAvailableStock(int componentId) {

        int stock = 0;

        try {

            String sql = "SELECT available_quantity FROM components WHERE component_id=?";

            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, componentId);

            ResultSet rs = ps.executeQuery();

            if (rs.next()) {

                stock = rs.getInt("available_quantity");

            }

        } catch (Exception e) {

            e.printStackTrace();

        }

        return stock;
    }
    public void showInventoryDashboard() {

        try {

            Statement st = con.createStatement();

            ResultSet rs = st.executeQuery(
                    "SELECT SUM(available_quantity) AS available, " +
                            "SUM(allocated_quantity) AS allocated, " +
                            "SUM(damaged_quantity) AS damaged FROM components");

            if (rs.next()) {

                System.out.println("\n========== INVENTORY DASHBOARD ==========");
                System.out.println("Available Stock : " + rs.getInt("available"));
                System.out.println("Allocated Stock : " + rs.getInt("allocated"));
                System.out.println("Damaged Stock   : " + rs.getInt("damaged"));
                System.out.println("=========================================");

            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}