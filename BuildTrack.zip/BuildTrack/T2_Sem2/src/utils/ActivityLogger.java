package utils;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;

public class ActivityLogger {

    public static void log(String activity) {
        try {
            System.out.println("Logger Called");

            File file = new File(System.getProperty("user.dir"), "logs.txt");

            System.out.println(file.getAbsolutePath());
            System.out.println("Log Path: " + file.getAbsolutePath());

            FileWriter writer = new FileWriter(file, true);
            writer.write(LocalDateTime.now() + " : " + activity + "\n");
            writer.close();

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}