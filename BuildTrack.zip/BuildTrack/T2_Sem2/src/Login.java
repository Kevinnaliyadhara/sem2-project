import java.util.Scanner;

public class Login {

    private String username = "admin";
    private String password = "admin123";

    public boolean login() {

        Scanner sc = new Scanner(System.in);

        while (true) {

            System.out.println("\n======================================");
            System.out.println(" CONSTRUCTION ASSET MANAGEMENT SYSTEM");
            System.out.println("======================================");

            System.out.print("Enter Username : ");
            String user = sc.nextLine();

            System.out.print("Enter Password : ");
            String pass = sc.nextLine();

            if (user.isEmpty() || pass.isEmpty()) {
                System.out.println("\nUsername or Password cannot be empty!");
                continue;
            }

            if (user.equals(username) && pass.equals(password)) {
                System.out.println("\nLogin Successful...");
                return true;
            } else {

                System.out.println("\n======================================");
                System.out.println(" Invalid Username or Password!");
                System.out.println(" Please Try Again.");
                System.out.println("======================================");
            }
        }
    }

    public static void main(String[] args) {

        Login login = new Login();

        if (login.login()) {
            System.out.println("\nWelcome to Construction Asset Management System");
        } else {
            System.out.println("\nProgram Closed.");
        }
    }
}