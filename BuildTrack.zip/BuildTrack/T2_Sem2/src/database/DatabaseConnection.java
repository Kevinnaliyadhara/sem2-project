package database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static final String URL = "jdbc:mysql://localhost:3306/construction_management";
    private static final String USER = "root";
    private static final String PASSWORD = "";

    public static Connection getConnection() {

        try {

            Connection con = DriverManager.getConnection(URL, USER, PASSWORD);
            con.setAutoCommit(false);


            return con;

        } catch (SQLException e) {

            System.out.println("Connection Failed!");

            e.printStackTrace();

            return null;
        }
    }
}
