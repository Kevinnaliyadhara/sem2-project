package validation;

import java.util.Scanner;

public class MenuValidator {

    public static int getChoice(Scanner sc, int min, int max) {

        while (true) {

            if (sc.hasNextInt()) {

                int choice = sc.nextInt();

                if (choice >= min && choice <= max) {

                    return choice;

                }

                System.out.print("Invalid Choice! Try Again : ");

            } else {

                System.out.print("Invalid Choice! Try Again : ");
                sc.next();
            }

        }

    }

}