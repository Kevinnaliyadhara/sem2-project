package validation;

import java.util.Scanner;

public class InputValidator {

    public static int getInt(Scanner sc, String message) {

        while (true) {

            System.out.print(message);

            if (sc.hasNextInt()) {
                return sc.nextInt();
            }

            System.out.println("Invalid Input! Please enter a valid number.");
            sc.nextLine();
        }
    }

    public static double getDouble(Scanner sc, String message) {

        while (true) {

            System.out.print(message);

            if (sc.hasNextDouble()) {
                return sc.nextDouble();
            }

            System.out.println("Invalid Input! Please enter a valid amount.");
            sc.nextLine();
        }
    }

    public static String getString(Scanner sc, String message) {

        sc.nextLine();

        while (true) {

            System.out.print(message);

            String value = sc.nextLine().trim();

            if (!value.isEmpty()) {
                return value;
            }

            System.out.println("Input cannot be empty.");
        }
    }
}