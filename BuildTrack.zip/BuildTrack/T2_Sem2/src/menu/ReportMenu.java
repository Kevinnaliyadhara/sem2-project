    package menu;

    import dao.ReportDAO;
    import dao.ProjectDAO;
    import java.util.Scanner;

    public class ReportMenu {

        public void showReportMenu() {

            Scanner sc = new Scanner(System.in);

            int reportChoice;

            do {

                System.out.println("\n========== REPORTS ==========");
                System.out.println("1. Client - Project Report");
                System.out.println("2. Full Project Report");
                System.out.println("3. Project Cost Report");
                System.out.println("4. Rental Income Report");
                System.out.println("5. Maintenance  Report");
                System.out.println("6. Available Scaffold Report");
                System.out.println("7. Back");
                System.out.print("Enter Choice : ");

                reportChoice = sc.nextInt();

                ReportDAO reportDAO = new ReportDAO();
                ProjectDAO projectDAO = new ProjectDAO();

                switch (reportChoice) {

                    case 1:
                        reportDAO.showClientProjectReport();
                        break;




                    case 2:
                        reportDAO.showFullProjectReport();
                        break;





                    case 3:
                        reportDAO.showProjectCostReport();
                        break;




                    case 4 :

                        reportDAO.showRentalIncomeReport();

                        break;

                    case 5:

                        reportDAO.showMaintenanceReport();

                        break;
                    case 6:
                    reportDAO.showAvailableScaffoldReport();

                    break;
                    case 7:
                        System.out.println("returning..");
                        break;
                    default:
                        System.out.println("Invalid Choice!");
                }

            } while (reportChoice != 7);
        }
    }