package menu;

import dao.MaintenanceDAO;
import model.Maintenance;
import validation.InputValidator;
import validation.MenuValidator;

import java.util.Scanner;

public class MaintenanceMenu {

    public void showMaintenanceMenu() {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n========== MAINTENANCE MANAGEMENT ==========");
            System.out.println("1. View Maintenance");
            System.out.println("2. Update Maintenance");
            System.out.println("3. Delete Maintenance");
            System.out.println("4. Back");
            System.out.print("Enter Choice : ");

            choice = MenuValidator.getChoice(sc,1,4);
            switch (choice) {


                case 1:

                    MaintenanceDAO viewDAO = new MaintenanceDAO();

                    System.out.println("\n========== MAINTENANCE LIST ==========");

                    viewDAO.displayMaintenance();

                    break;

                case 2:

                    sc.nextLine();

                    Maintenance update = new Maintenance();

                    update.setMaintenanceId(
                            InputValidator.getInt(sc, "Enter Maintenance ID : "));

                    System.out.print("Enter Scaffold ID : ");
                    update.setScaffoldId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Maintenance Date (YYYY-MM-DD) : ");
                    update.setMaintenanceDate(sc.nextLine());

                    System.out.print("Enter Maintenance Type : ");
                    update.setMaintenanceType(sc.nextLine());

                    System.out.print("Enter Cost : ");
                    update.setMaintenanceCost(sc.nextDouble());
                    sc.nextLine();

                    System.out.print("Enter Completed Date (YYYY-MM-DD) : ");
                    update.setCompletedDate(sc.nextLine());

                    System.out.print("Enter Status : ");
                    update.setStatus(sc.nextLine());

                    MaintenanceDAO updateDAO = new MaintenanceDAO();

                    if (updateDAO.updateMaintenance(update))
                        System.out.println("\nMaintenance Updated Successfully.");
                    else
                        System.out.println("\nFailed To Update Maintenance.");

                    break;
                case 3:

                    System.out.print("Enter Maintenance ID : ");

                    int id = sc.nextInt();

                    MaintenanceDAO deleteDAO = new MaintenanceDAO();

                    if (deleteDAO.deleteMaintenance(id))
                        System.out.println("\nMaintenance Deleted Successfully.");
                    else
                        System.out.println("\nFailed To Delete Maintenance.");

                    break;

                case 4:

                    System.out.println("Returning...");
                    break;


                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 4);
    }
}