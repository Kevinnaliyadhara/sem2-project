package menu;

import dao.ClientDAO;
import model.Client;
import validation.MenuValidator;

import java.util.Scanner;

public class ClientMenu {

    public void showClientMenu() {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n========== CLIENT MANAGEMENT ==========");
            System.out.println("1. Add Client");
            System.out.println("2. View Clients");
            System.out.println("3. Search Client");
            System.out.println("4. Back");
            System.out.print("Enter Choice : ");

            choice = MenuValidator.getChoice(sc, 1, 6);

            switch (choice) {

                case 1:

                    sc.nextLine();

                    Client client = new Client();

                    System.out.print("Enter Company Name : ");
                    client.setCompanyName(sc.nextLine());

                    System.out.print("Enter Phone : ");
                    client.setPhone(sc.nextLine());

                    System.out.print("Enter Email : ");
                    client.setEmail(sc.nextLine());

                    System.out.print("Enter Address : ");
                    client.setAddress(sc.nextLine());

                    ClientDAO clientDAO = new ClientDAO();

                    if (clientDAO.addClient(client)) {
                        System.out.println("\nClient Added Successfully.");
                    } else {
                        System.out.println("\nFailed to Add Client.");
                    }

                    break;

                case 2:

                    ClientDAO dao = new ClientDAO();

                    dao.displayClients();

                    break;

                case 3:

                    sc.nextLine();

                    System.out.print("Enter Client Name : ");

                    String name = sc.nextLine();

                    ClientDAO searchDAO = new ClientDAO();

                    searchDAO.searchClientByName(name);

                    break;

                case 4:

                    System.out.println("Returning...");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 4);
    }
}