package menu;

import dao.ComponentDAO;
import dao.UserDAO;

import java.util.Scanner;

public class MainMenu {
    boolean loggedIn = false;

    public void start() {

        Scanner sc = new Scanner(System.in);

        int choice;


        do {

            System.out.println("\n======================================");
            System.out.println("      BUILDTRACK MANAGEMENT SYSTEM");
            System.out.println("======================================");
            while (!loggedIn) {

                System.out.println("\n========== LOGIN ==========");

                System.out.print("Username : ");
                String username = sc.nextLine();

                System.out.print("Password : ");
                String password = sc.nextLine();

                UserDAO dao = new UserDAO();

                if (dao.login(username, password)) {

                    System.out.println("\nLogin Successful.");

                    loggedIn = true;

                } else {

                    System.out.println("\nInvalid Username or Password.");
                }
            }
            System.out.println("2. Client Management");
            System.out.println("3. Project Management");
            System.out.println("4. Site Management");
            System.out.println("5. Scaffold Management");
            System.out.println("6. Component Management");
            System.out.println("7. Allocation Management");
            System.out.println("8. Maintenance Management");
            System.out.println("9. Reports");
            System.out.println("10. Search");
            System.out.println("11.Inventory Dashboard");
            System.out.println("12.logout");
            System.out.println("13. Exit");


            while (true) {

                System.out.print("Enter Choice : ");

                if (sc.hasNextInt()) {

                    choice = sc.nextInt();

                    if (choice >= 1 && choice <= 11) {   // Main Menu માં જેટલા options હોય
                        break;
                    } else {
                        System.out.println("\nInvalid Choice! Please Try Again.");
                    }

                } else {

                    System.out.println("\nInvalid Choice! Please Try Again.");
                    sc.next(); // Invalid input remove

                }

            }

            switch (choice) {

                case 1:

                    sc.nextLine();

                    System.out.print("Enter Username : ");
                    String username = sc.nextLine();

                    System.out.print("Enter Password : ");
                    String password = sc.nextLine();

                    UserDAO userDAO = new UserDAO();

                    if (userDAO.login(username, password)) {
                        System.out.println("\nLogin Successful!");
                    } else {
                        System.out.println("\nInvalid Username or Password!");
                    }

                    break;

                case 2:

                    ClientMenu clientMenu = new ClientMenu();
                    clientMenu.showClientMenu();

                    break;

                case 3:

                    ProjectMenu projectMenu = new ProjectMenu();
                    projectMenu.showProjectMenu();

                    break;

                case 4:

                    SiteMenu siteMenu = new SiteMenu();
                    siteMenu.showSiteMenu();

                    break;
                case 5:

                    ScaffoldMenu scaffoldMenu = new ScaffoldMenu();
                    scaffoldMenu.showScaffoldMenu();

                    break;
                case 6:

                    ComponentMenu componentMenu = new ComponentMenu();
                    componentMenu.showComponentMenu();

                    break;
                case 7:

                    AllocationMenu allocationMenu = new AllocationMenu();
                    allocationMenu.showAllocationMenu();

                    break;
                case 8:

                    MaintenanceMenu maintenanceMenu = new MaintenanceMenu();
                    maintenanceMenu.showMaintenanceMenu();

                    break;
                case 9:

                    ReportMenu reportMenu = new ReportMenu();
                    reportMenu.showReportMenu();

                    break;

                case 10:

                    SearchMenu searchMenu = new SearchMenu();
                    searchMenu.showSearchMenu();

                    break;
                case 11:
                    new ComponentDAO().showInventoryDashboard();
                    break;

                 case 12:

                    loggedIn = false;

                    break;
                case 13:

                    break;

                default:

                    System.out.println("\nInvalid Choice!");
            }

        } while (choice != 12);
    }
}