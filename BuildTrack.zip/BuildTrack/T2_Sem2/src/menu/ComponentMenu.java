package menu;

import dao.ComponentDAO;
import model.Component;
import validation.MenuValidator;

import java.util.Scanner;

public class ComponentMenu {


    public void showComponentMenu() {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n========== COMPONENT MANAGEMENT ==========");
            System.out.println("1. Add Component");
            System.out.println("2. View Components");
            System.out.println("3. Update Component");
            System.out.println("4. Delete Component");
            System.out.println("5. Back");
            System.out.print("Enter Choice : ");

            choice = MenuValidator.getChoice(sc,1,5);

            switch (choice) {

                case 1:

                    sc.nextLine();

                    Component component = new Component();

                    System.out.print("Enter Scaffold ID : ");
                    component.setScaffoldId(sc.nextInt());
                    sc.nextLine();

                    int category;
                    while(true)
                    {
                    System.out.println("\n=========== CATEGORY ===========");
                    System.out.println("1. Scaffold Components");
                    System.out.println("2. Safety Equipment");
                    System.out.println("3. Machinery");
                    System.out.print("Select Category : ");

                    category = sc.nextInt();
                    sc.nextLine();
                        if (category >= 1 && category <= 3) {
                            break;
                        }

                        System.out.println("\nInvalid Category! Please Try Again.");
                    }

                    switch (category) {

                        case 1:

                            System.out.println("\n----- Scaffold Components -----");
                            System.out.println("1. Scaffold Frame");
                            System.out.println("2. Cross Brace");
                            System.out.println("3. Base Jack");
                            System.out.println("4. U Head Jack");
                            System.out.println("5. Steel Plank");
                            System.out.println("6. Pipe");
                            System.out.println("7. Coupler");
                            System.out.print("Select Component : ");

                            int scaffoldChoice = sc.nextInt();
                            sc.nextLine();

                            switch (scaffoldChoice) {
                                case 1 -> component.setComponentName("Scaffold Frame");
                                case 2 -> component.setComponentName("Cross Brace");
                                case 3 -> component.setComponentName("Base Jack");
                                case 4 -> component.setComponentName("U Head Jack");
                                case 5 -> component.setComponentName("Steel Plank");
                                case 6 -> component.setComponentName("Pipe");
                                case 7 -> component.setComponentName("Coupler");
                                default -> {
                                    System.out.println("Invalid Choice");
                                    continue;
                                }
                            }
                            break;

                        case 2:

                            System.out.println("\n----- Safety Equipment -----");
                            System.out.println("1. Safety Helmet");
                            System.out.println("2. Safety Belt");
                            System.out.println("3. Safety Net");
                            System.out.print("Select Component : ");

                            int safetyChoice = sc.nextInt();
                            sc.nextLine();

                            switch (safetyChoice) {
                                case 1 -> component.setComponentName("Safety Helmet");
                                case 2 -> component.setComponentName("Safety Belt");
                                case 3 -> component.setComponentName("Safety Net");
                                default -> {
                                    System.out.println("Invalid Choice");
                                    continue;
                                }
                            }
                            break;

                        case 3:

                            System.out.println("\n----- Machinery -----");
                            System.out.println("1. JCB");
                            System.out.println("2. Generator");
                            System.out.println("3. Concrete Mixer");
                            System.out.print("Select Component : ");

                            int machineChoice = sc.nextInt();
                            sc.nextLine();

                            switch (machineChoice) {
                                case 1 -> component.setComponentName("JCB");
                                case 2 -> component.setComponentName("Generator");
                                case 3 -> component.setComponentName("Concrete Mixer");
                                default -> {
                                    System.out.println("Invalid Choice");
                                    continue;
                                }
                            }
                            break;

                        default:
                            System.out.println("Invalid Category");
                            break;
                    }

                    int qty;

                    while (true) {

                        System.out.print("Enter Quantity : ");

                        qty = sc.nextInt();

                        if (qty > 0) {
                            break;
                        }

                        System.out.println("Quantity must be greater than 0.");
                    }

                    component.setQuantity(qty);

                    sc.nextLine();
                    String condition;

                    while (true) {

                        System.out.print("Enter Component Condition (Good/Damaged) : ");

                        condition = sc.nextLine();

                        if (condition.equalsIgnoreCase("Good") ||
                                condition.equalsIgnoreCase("Damaged")) {
                            break;
                        }

                        System.out.println("Invalid Condition! Enter Good or Damaged.");
                    }

                    component.setComponentCondition(condition);
                    ComponentDAO addDAO = new ComponentDAO();

                    if (addDAO.addComponent(component)) {
                        System.out.println("\nComponent Added Successfully.");
                    } else {
                        System.out.println("\nFailed To Add Component.");
                    }

                    break;

                case 2:

                    ComponentDAO viewDAO = new ComponentDAO();

                    System.out.println("\n========== COMPONENT LIST ==========");

                    viewDAO.displayComponents();

                    break;

                case 3:

                    sc.nextLine();

                    Component update = new Component();

                    System.out.print("Enter Component ID : ");
                    update.setComponentId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Scaffold ID : ");
                    update.setScaffoldId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Component Name : ");
                    update.setComponentName(sc.nextLine());

                    System.out.print("Enter Quantity : ");
                    update.setQuantity(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Component Condition : ");
                    update.setComponentCondition(sc.nextLine());

                    ComponentDAO updateDAO = new ComponentDAO();

                    if (updateDAO.updateComponent(update)) {
                        System.out.println("\nComponent Updated Successfully.");
                    } else {
                        System.out.println("\nComponent ID Not Found.");                    }

                    break;

                case 4:

                    System.out.print("Enter Component ID : ");

                    int id = sc.nextInt();

                    ComponentDAO deleteDAO = new ComponentDAO();

                    if (deleteDAO.deleteComponent(id)) {
                        System.out.println("\nComponent Deleted Successfully.");
                    } else {
                        System.out.println("\nComponent Not Found OR Already Allocated.");                    }

                    break;

                case 5:

                    System.out.println("Returning...");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 5);
    }
}