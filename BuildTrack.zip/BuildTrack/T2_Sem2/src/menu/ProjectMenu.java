package menu;

import dao.ProjectDAO;
import model.Project;

import java.util.Scanner;

public class ProjectMenu {

    public void showProjectMenu() {

        Scanner sc = new Scanner(System.in);
        ProjectDAO projectDAO = new ProjectDAO();
        int choice;

        do {

            System.out.println("\n========== PROJECT MANAGEMENT ==========");
            System.out.println("1. Add Project");
            System.out.println("2. View Projects");
            System.out.println("3. Update Project");
            System.out.println("4. Delete Project");
            System.out.println("5. Search Project By Cost");
            System.out.println("6. Highest Cost Project");
            System.out.println("7. Projects Above Average Cost");
            System.out.println("8. Back");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:
                    sc.nextLine();

                    Project project = new Project();

                    System.out.print("Enter Client ID : ");
                    project.setClientId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Project Name : ");
                    project.setProjectName(sc.nextLine());

                    System.out.print("Enter Start Date : ");
                    project.setStartDate(sc.nextLine());

                    System.out.print("Enter End Date : ");
                    project.setEndDate(sc.nextLine());

                    System.out.print("Enter Status : ");
                    project.setStatus(sc.nextLine());

                    System.out.print("Enter Estimated Cost : ");
                    project.setEstimatedCost(sc.nextDouble());

                    if(projectDAO.addProject(project))
                        System.out.println("Project Added Successfully.");
                    else
                        System.out.println("Failed to Add Project.");

                    break;

                case 2:
                    projectDAO.displayProjects();
                    break;

                case 3:
                    sc.nextLine();

                    Project update = new Project();

                    System.out.print("Enter Project ID : ");
                    update.setProjectId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Client ID : ");
                    update.setClientId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Project Name : ");
                    update.setProjectName(sc.nextLine());

                    System.out.print("Enter Start Date : ");
                    update.setStartDate(sc.nextLine());

                    System.out.print("Enter End Date : ");
                    update.setEndDate(sc.nextLine());

                    System.out.print("Enter Status : ");
                    update.setStatus(sc.nextLine());

                    System.out.print("Enter Estimated Cost : ");
                    update.setEstimatedCost(sc.nextDouble());

                    if(projectDAO.updateProject(update))
                        System.out.println("Project Updated Successfully.");
                    else
                        System.out.println("Failed to Update Project.");

                    break;

                case 4:
                    System.out.print("Enter Project ID : ");
                    int id = sc.nextInt();

                    if(projectDAO.deleteProject(id))
                        System.out.println("Project Deleted Successfully.");
                    else
                        System.out.println("Failed to Delete Project.");

                    break;

                case 5:
                    System.out.print("Enter Minimum Cost : ");
                    double min = sc.nextDouble();

                    System.out.print("Enter Maximum Cost : ");
                    double max = sc.nextDouble();

                    projectDAO.searchProjectByCost(min, max);
                    break;

                case 6:
                    projectDAO.showHighestCostProject();
                    break;

                case 7:
                    projectDAO.showProjectsAboveAverageCost();
                    break;

                case 8:
                    System.out.println("Returning...");
                    break;

                default:
                    System.out.println("Invalid Choice!");
            }

        } while(choice != 8);
    }
}
