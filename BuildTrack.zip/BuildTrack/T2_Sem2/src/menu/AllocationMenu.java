package menu;

import dao.AllocationDAO;
import exception.InvalidMaintenanceCostException;
import exception.InvalidQuantityException;
import exception.InvalidRentException;
import model.Allocation;
import validation.MenuValidator;

import java.util.Scanner;

public class AllocationMenu {

    public void showAllocationMenu() {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n========== ALLOCATION MANAGEMENT ==========");
            System.out.println("1. Allocate Scaffold");
            System.out.println("2. Return Scaffold");
            System.out.println("3. View Allocations");
            System.out.println("4. Update Allocation");
            System.out.println("5. Delete Allocation");
            System.out.println("6. Back");
            System.out.print("Enter Choice : ");

            choice = MenuValidator.getChoice(sc,1,6);

            switch (choice) {

                case 1:

                    Allocation allocation = new Allocation();

                    System.out.print("Enter Scaffold ID : ");
                    allocation.setScaffoldId(sc.nextInt());

                    System.out.print("Enter Component ID : ");
                    allocation.setComponentId(sc.nextInt());

                    int qty;

                    while (true) {

                        try {
                            System.out.print("Enter Quantity : ");
                            qty = sc.nextInt();

                            if (qty <= 0) {
                                throw new InvalidQuantityException("Quantity must be greater than 0.");


                            }

                            allocation.setQuantity(qty);
                            System.out.print("Enter Project ID : ");
                            allocation.setProjectId(sc.nextInt());

                            System.out.print("Enter Site ID : ");
                            allocation.setSiteId(sc.nextInt());

                            break;
                        } catch (InvalidQuantityException e) {

                            System.out.println(e.getMessage());

                        } catch (Exception e) {

                            System.out.println("Error : " + e.getMessage());

                        }
                    }

                        double rent;

                    while (true) {

                        try
                        {

                        System.out.print("Enter Rent Per Day : ");
                        rent = sc.nextDouble();

                        if (rent <= 0) {
                            throw new InvalidRentException("Rent must be greater than 0.");
                        }

                        break;

                    } catch (InvalidRentException e) {

                    System.out.println(e.getMessage());

                }


                    }

                    allocation.setRentPerDay(rent);

                    sc.nextLine();

                    System.out.print("Enter Allocation Date (YYYY-MM-DD) : ");
                    allocation.setAllocationDate(sc.nextLine());

                    System.out.print("Enter Expected Return Date (YYYY-MM-DD) : ");
                    allocation.setReturnDate(sc.nextLine());

                    // Automatic Values
                    allocation.setActualReturnDate("");
                    allocation.setRentAmount(0);
                    allocation.setLateDays(0);
                    allocation.setPenalty(0);
                    allocation.setConditionStatus("Good");
                    allocation.setStatus("Allocated");

                    AllocationDAO addDAO = new AllocationDAO();

                    if (addDAO.addAllocation(allocation)) {
                        System.out.println("\n====================================");
                        System.out.println("Allocation Successful");
                        System.out.println("Scaffold Status : Allocated");
                        System.out.println("Rent Started Successfully");
                        System.out.println("====================================");
                    } else {
                        System.out.println("\nFailed To Add Allocation.");
                    }

                    break;
                case 2:

                    sc.nextLine();

                    System.out.println("\n========== RETURN SCAFFOLD ==========");

                    System.out.print("Enter Allocation ID : ");
                    int allocationId = sc.nextInt();

                    sc.nextLine();

                    System.out.print("Enter Actual Return Date (YYYY-MM-DD) : ");
                    String actualDate = sc.nextLine();

                    System.out.print("Enter Condition (Good/Damaged) : ");
                    String condition = sc.nextLine();

                    double maintenanceCost;

                    while (true) {

                        try
                        {

                        System.out.print("Enter Maintenance Cost : ");
                        maintenanceCost = sc.nextDouble();

                        if (maintenanceCost < 0) {
                            throw new InvalidMaintenanceCostException("Maintenance Cost cannot be negative.");
                        }

                        break;

                    } catch (InvalidMaintenanceCostException e) {

                    System.out.println(e.getMessage());

                }

                    }

                    AllocationDAO dao = new AllocationDAO();

                    if (dao.returnScaffold(allocationId, actualDate, condition, maintenanceCost)) {
                        System.out.println("\nScaffold Returned Successfully.");

                    } else {

                        System.out.println("\nReturn Failed.");

                    }

                    break;

                case 3:

                    new AllocationDAO().displayAllocations();

                    break;

                case 4:

                    sc.nextLine();

                    Allocation update = new Allocation();

                    System.out.print("Enter Allocation ID : ");
                    update.setAllocationId(sc.nextInt());

                    System.out.print("Enter Scaffold ID : ");
                    update.setScaffoldId(sc.nextInt());

                    System.out.print("Enter Project ID : ");
                    update.setProjectId(sc.nextInt());

                    System.out.print("Enter Site ID : ");
                    update.setSiteId(sc.nextInt());



                    System.out.print("Enter Rent Per Day : ");
                    update.setRentPerDay(sc.nextDouble());

                    sc.nextLine();

                    System.out.print("Enter Allocation Date (YYYY-MM-DD) : ");
                    update.setAllocationDate(sc.nextLine());

                    System.out.print("Enter Expected Return Date (YYYY-MM-DD) : ");
                    update.setReturnDate(sc.nextLine());

                    AllocationDAO updateDAO = new AllocationDAO();

                    if(updateDAO.updateAllocation(update)){

                        System.out.println("\nAllocation Updated Successfully.");

                    }else{

                        System.out.println("\nFailed To Update Allocation.");

                    }

                    break;

                case 5:

                    System.out.print("Enter Allocation ID : ");

                    int id = sc.nextInt();

                    if (new AllocationDAO().deleteAllocation(id)) {
                        System.out.println("\nAllocation Deleted Successfully.");
                    } else {
                        System.out.println("\nFailed To Delete Allocation.");
                    }

                    break;

                case 6:

                    System.out.println("Returning...");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 6);
    }
}