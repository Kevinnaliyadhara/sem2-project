package menu;

import dao.ClientDAO;
import dao.ProjectDAO;
import java.util.Scanner;
import java.util.HashMap;
import model.Client;

public class SearchMenu {

    public void showSearchMenu() {

        Scanner sc = new Scanner(System.in);

        int searchChoice;

        do {

            System.out.println("\n========== SEARCH ==========");
            System.out.println("1. Search Client");
            System.out.println("2. Search Project");
            System.out.println("3. hightcostproject");
            System.out.println("4. Search Client by ID (HashMap)");
            System.out.println("5. Back");
            System.out.print("Enter Choice : ");

            searchChoice = sc.nextInt();
            sc.nextLine();

            switch (searchChoice) {

                case 1:

                    System.out.print("Enter Client Name : ");
                    String clientName = sc.nextLine();

                    ClientDAO clientDAO = new ClientDAO();

                    clientDAO.searchClientByName(clientName);

                    break;

                case 2:

                    System.out.print("Enter Minimum Cost : ");
                    double min = sc.nextDouble();

                    System.out.print("Enter Maximum Cost : ");
                    double max = sc.nextDouble();

                    ProjectDAO projectDAO = new ProjectDAO();

                    projectDAO.searchProjectByCost(min, max);

                    break;



                case 3:

                    ProjectDAO projectDAO1 = new ProjectDAO();
                    projectDAO1.showHighestCostProject();

                    break;

                case 4:

                    System.out.print("Enter Client ID : ");
                    int id = sc.nextInt();

                    ClientDAO clientDAO1 = new ClientDAO();

                    HashMap<Integer, Client> clientMap = clientDAO1.getClientMap();

                    Client client = clientMap.get(id);

                    if (client != null) {

                        client.displayClient();

                    } else {

                        System.out.println("Client Not Found!");
                    }

                    break;
                case 5:
                    System.out.println("Returning...");
                    break;

                default:
                    System.out.println("Invalid Choice!");

            }

        } while (searchChoice != 5);
    }
}