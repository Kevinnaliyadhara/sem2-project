package menu;

import dao.SiteDAO;
import dao.SiteAreaDAO;
import model.Site;
import model.SiteArea;

import java.util.Scanner;

public class SiteMenu {

    public void showSiteMenu() {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n========== SITE MANAGEMENT ==========");
            System.out.println("1. Add Site");
            System.out.println("2. View Sites");
            System.out.println("3. Add Site Area");
            System.out.println("4. View Site Areas");
            System.out.println("5. Back");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    sc.nextLine();

                    Site site = new Site();

                    System.out.print("Enter Project ID : ");
                    site.setProjectId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Site Name : ");
                    site.setSiteName(sc.nextLine());

                    System.out.print("Enter Location : ");
                    site.setLocation(sc.nextLine());

                    System.out.print("Enter Latitude : ");
                    site.setLatitude(sc.nextDouble());

                    System.out.print("Enter Longitude : ");
                    site.setLongitude(sc.nextDouble());

                    SiteDAO siteDAO = new SiteDAO();

                    if (siteDAO.addSite(site)) {
                        System.out.println("\nSite Added Successfully.");
                    } else {
                        System.out.println("\nFailed to Add Site.");
                    }

                    break;

                case 2:

                    SiteDAO dao = new SiteDAO();

                    System.out.println("\n===== SITE LIST =====");

                    dao.displaySites();

                    break;

                case 3:

                    sc.nextLine();

                    SiteArea area = new SiteArea();

                    System.out.print("Enter Site ID : ");
                    area.setSiteId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Area Name : ");
                    area.setAreaName(sc.nextLine());

                    SiteAreaDAO areaDAO = new SiteAreaDAO();

                    if (areaDAO.addSiteArea(area)) {
                        System.out.println("\nSite Area Added Successfully.");
                    } else {
                        System.out.println("\nFailed to Add Site Area.");
                    }

                    break;

                case 4:

                    SiteAreaDAO dao2 = new SiteAreaDAO();

                    System.out.println("\n===== SITE AREA LIST =====");

                    dao2.displaySiteAreas();

                    break;

                case 5:

                    System.out.println("Returning...");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 5);
    }
}