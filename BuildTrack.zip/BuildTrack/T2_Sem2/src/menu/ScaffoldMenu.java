package menu;

import dao.ScaffoldDAO;
import model.Scaffold;

import java.util.Scanner;

public class ScaffoldMenu {

    public void showScaffoldMenu() {

        Scanner sc = new Scanner(System.in);

        int choice;

        do {

            System.out.println("\n========== SCAFFOLD MANAGEMENT ==========");
            System.out.println("1. Add Scaffold");
            System.out.println("2. View Scaffolds");
            System.out.println("3. Update Scaffold");
            System.out.println("4. Delete Scaffold");
            System.out.println("5. Back");
            System.out.print("Enter Choice : ");

            choice = sc.nextInt();

            switch (choice) {

                case 1:

                    sc.nextLine();

                    Scaffold scaffold = new Scaffold();

                    System.out.print("Enter Scaffold Code : ");
                    scaffold.setScaffoldCode(sc.nextLine());

                    System.out.print("Enter Scaffold Type : ");
                    scaffold.setScaffoldType(sc.nextLine());

                    System.out.print("Enter Status : ");
                    scaffold.setStatus(sc.nextLine());

                    System.out.print("Enter Current Site id : ");
                    scaffold.setCurrentSite(sc.nextLine());

                    System.out.print("Enter Current Area id : ");
                    scaffold.setCurrentArea(sc.nextLine());

                    ScaffoldDAO addDAO = new ScaffoldDAO();

                    if (addDAO.addScaffold(scaffold)) {
                        System.out.println("\nScaffold Added Successfully.");
                    } else {
                        System.out.println("\nFailed To Add Scaffold.");
                    }

                    break;

                case 2:

                    ScaffoldDAO viewDAO = new ScaffoldDAO();

                    System.out.println("\n========== SCAFFOLD LIST ==========");

                    viewDAO.displayScaffolds();

                    break;

                case 3:

                    sc.nextLine();

                    Scaffold update = new Scaffold();

                    System.out.print("Enter Scaffold ID : ");
                    update.setScaffoldId(sc.nextInt());
                    sc.nextLine();

                    System.out.print("Enter Scaffold Code : ");
                    update.setScaffoldCode(sc.nextLine());

                    System.out.print("Enter Scaffold Type : ");
                    update.setScaffoldType(sc.nextLine());

                    System.out.print("Enter Status : ");
                    update.setStatus(sc.nextLine());

                    System.out.print("Enter Current Site id: ");
                    update.setCurrentSite(sc.nextLine());

                    System.out.print("Enter Current Area id: ");
                    update.setCurrentArea(sc.nextLine());

                    ScaffoldDAO updateDAO = new ScaffoldDAO();

                    if (updateDAO.updateScaffold(update)) {
                        System.out.println("\nScaffold Updated Successfully.");
                    } else {
                        System.out.println("\nFailed To Update Scaffold.");
                    }

                    break;

                case 4:

                    System.out.print("Enter Scaffold ID : ");

                    int id = sc.nextInt();

                    ScaffoldDAO deleteDAO = new ScaffoldDAO();

                    if (deleteDAO.deleteScaffold(id)) {
                        System.out.println("\nScaffold Deleted Successfully.");
                    } else {
                        System.out.println("\nFailed To Delete Scaffold.");
                    }

                    break;

                case 5:

                    System.out.println("Returning...");
                    break;

                default:

                    System.out.println("Invalid Choice!");
            }

        } while (choice != 5);
    }
}