package datastructure;

import java.util.PriorityQueue;
import datastructure.PriorityMaintenanceQueue;

public class PriorityMaintenanceQueue {

    private PriorityQueue<String> queue = new PriorityQueue<>();

    public void addRequest(String request) {

        queue.offer(request);

        System.out.println("Request Added : " + request);
    }

    public void processRequest() {

        if(queue.isEmpty()) {

            System.out.println("No Pending Requests.");

        } else {

            System.out.println("Processing : " + queue.poll());

        }
    }

    public void displayRequests() {

        System.out.println(queue);
    }
}