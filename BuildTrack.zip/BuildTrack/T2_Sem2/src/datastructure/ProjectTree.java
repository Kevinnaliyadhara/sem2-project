package datastructure;

public class ProjectTree {

    public void displayHierarchy() {

        System.out.println("BuildTrack");

        System.out.println("|-- Project : Metro Bridge");

        System.out.println("|     |-- Site : Ahmedabad");

        System.out.println("|     |      |-- Area : Block A");

        System.out.println("|     |      |-- Area : Block B");

        System.out.println("|");

        System.out.println("|-- Project : Highway");

        System.out.println("      |-- Site : Surat");

        System.out.println("             |-- Area : Zone 1");

        System.out.println("             |-- Area : Zone 2");

    }
}