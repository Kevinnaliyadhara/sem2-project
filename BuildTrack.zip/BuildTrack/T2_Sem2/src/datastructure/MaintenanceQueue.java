package datastructure;

import java.util.LinkedList;
import java.util.Queue;

public class MaintenanceQueue {

    private Queue<String> queue = new LinkedList<>();

    public void addRequest(String request) {

        queue.offer(request);

        System.out.println("Request Added : " + request);
    }

    public void processRequest() {

        if(queue.isEmpty()) {

            System.out.println("No Pending Requests.");

        } else {

            System.out.println("Processing : " + queue.poll());

        }
    }

    public void displayQueue() {

        System.out.println(queue);
    }

}