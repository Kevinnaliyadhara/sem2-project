    package datastructure;

    import java.util.Stack;

    public class OperationStack {

        private Stack<String> stack = new Stack<>();

        public void pushOperation(String operation) {

            stack.push(operation);

            System.out.println("Operation Saved : " + operation);
        }

        public void undoOperation() {

            if(stack.isEmpty()) {

                System.out.println("No Operation to Undo.");

            } else {

                System.out.println("Undo : " + stack.pop());

            }
        }

        public void displayHistory() {

            System.out.println(stack);
        }
    }