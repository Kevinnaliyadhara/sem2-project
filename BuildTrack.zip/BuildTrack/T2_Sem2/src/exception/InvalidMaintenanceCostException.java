package exception;

public class InvalidMaintenanceCostException extends Exception {

    public InvalidMaintenanceCostException(String message) {
        super(message);
    }
}