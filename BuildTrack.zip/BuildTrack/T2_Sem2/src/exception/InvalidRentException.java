package exception;

public class InvalidRentException extends Exception {

    public InvalidRentException(String message) {
        super(message);
    }
}